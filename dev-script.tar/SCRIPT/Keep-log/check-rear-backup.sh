#!/bin/bash

# Variables
LOG_DIR="/var/log/rear"
HOSTNAME=$(hostname)
LOG_FILE="$LOG_DIR/rear-$HOSTNAME.log"
OUTPUT_FILE="/tmp/rear-$HOSTNAME-$(date +%Y%m%d).log"

# Check if the log file exists
if [[ ! -f $LOG_FILE ]]; then
  echo "Log file $LOG_FILE not found." > "$OUTPUT_FILE"
  exit 1
fi

# Analyze the log file
if grep -q "completed successfully" "$LOG_FILE"; then
  echo "Backup completed successfully for $HOSTNAME." > "$OUTPUT_FILE"
elif grep -q "Backup failed" "$LOG_FILE"; then
  echo "Backup failed for $HOSTNAME. Check the logs at $LOG_FILE for details." > "$OUTPUT_FILE"
else
  echo "No definitive success or failure message found in $LOG_FILE." > "$OUTPUT_FILE"
fi

# Output results
echo "Check completed. Results saved in $OUTPUT_FILE."

