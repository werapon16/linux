#!/bin/bash

EMAIL="werapon_jar@freewillcomserv.com"
TMP_FILE="/tmp/display.txt"
SUBJECT="Server Info from $(hostname)"
DATE=`date`
STIME=`chronyc sources`
BOUNDARY="$(uuidgen)"  # Creatr boundary For MIME

# Create File Data
{
    echo "Hostname: $(hostname)"
    echo "DATE Time: $DATE"
    echo "IP Address: $(hostname -I | awk '{print $1}')"
    if [ -f /etc/os-release ]; then
        echo "OS Version: $(source /etc/os-release && echo $PRETTY_NAME)"
    else
        echo "OS Version: Unavailable"
    fi
    echo "SyncTime: $STIME"
} > "$TMP_FILE"

# Verify The File
if [ ! -f "$TMP_FILE" ]; then
    echo "Failed to create $TMP_FILE"
    exit 1
fi

# Verify Email
read -p "Ensure This $EMAIL is Ture? (y/n): " confirm
if [[ $confirm != "y" && $confirm != "Y" ]]; then
    read -p "Please Enter New E-mail: " NEW_EMAIL
    EMAIL=$NEW_EMAIL
    read -p "Ensure This Email:$EMAIL is Ture? (y/n): " confirm_new
    if [[ $confirm_new != "y" && $confirm_new != "Y" ]]; then
        echo "Send main false"
        exit 1
    fi
fi

# Create Content mail type MIME
{
    echo "Subject: $SUBJECT"
    echo "To: $EMAIL"
    echo "MIME-Version: 1.0"
    echo "Content-Type: multipart/mixed; boundary=\"$BOUNDARY\""
    echo ""
    echo "--$BOUNDARY"
    echo "Content-Type: text/plain; charset=UTF-8"
    echo "Content-Transfer-Encoding: 7bit"
    echo ""
    echo "This email contains server information as an attachment."
    echo ""
    echo "--$BOUNDARY"
    echo "Content-Type: text/plain; charset=UTF-8; name=\"$(basename $TMP_FILE)\""
    echo "Content-Disposition: attachment; filename=\"$(basename $TMP_FILE)\""
    echo "Content-Transfer-Encoding: base64"
    echo ""
    base64 "$TMP_FILE"
    echo ""
    echo "--$BOUNDARY--"
} | sendmail -t -i

#Verify sendmail
if [ $? -eq 0 ]; then
    echo "Email sent successfully to $EMAIL"
else
    echo "Failed to send email."
    exit 1
fi
