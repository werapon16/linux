#!/bin/bash

# Configuration
LOG_FILE="/var/log/rhel_subscription.log"
START_TIME=$(date +%s)
ERROR_OCCURRED=false

# Function to display progress with timestamp
progress() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# Function to log errors with timestamp
log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" >> "$LOG_FILE"
    ERROR_OCCURRED=true
}

# Secure credential handling
cleanup_credentials() {
    unset username
    unset password
    progress "Credentials cleared from memory"
}

# Redirect stderr to log_error function
exec 2> >(while read -r line; do log_error "$line"; done)

# Function to calculate execution duration
calculate_duration() {
    END_TIME=$(date +%s)
    DURATION=$((END_TIME - START_TIME))
    HOURS=$((DURATION / 3600))
    MINUTES=$(( (DURATION % 3600) / 60 ))
    SECONDS=$((DURATION % 60))
    echo -e "\n Total execution time: ${HOURS}h ${MINUTES}m ${SECONDS}s"
    
    if $ERROR_OCCURRED; then
        echo "Script completed with errors"
        exit 1
    else
        echo "Script completed successfully"
        exit 0
    fi
}

# Set trap to calculate duration on exit
trap calculate_duration EXIT
trap cleanup_credentials EXIT

# Main function
manage_subscription() {
    progress "������ Starting RHEL Subscription Process..."
    
    # Step 1: Clear User Input
    echo "----------------------------------------"
    echo "|    Red Hat Subscription Management   |"
    echo "----------------------------------------"
    
    # Get username with validation
    echo "Enter Red Hat username:"
    while true; do
        read -p "Enter Red Hat username:" username
        if [ -n "$username" ]; then
            break
        else
            echo " Error: Username cannot be empty!"
        fi
    done

    # Get password with validation
    echo "Enter Red Hat password:"
    while true; do
        read -s -p " Enter Red Hat password: " password
        echo
        if [ -n "$password" ]; then
            break
        else
            echo "Error: Password cannot be empty!"
        fi
    done

    # Step 2: Force Registration
    progress "Step 1/6 - Force registering system..."
    if ! subscription-manager register --force --username "$username" --password "$password" --auto-attach; then
        log_error "Force registration failed"
        exit 1
    fi

    # Step 3: Check Upgrade Versions
    progress "Step 2/6 - Checking upgrade versions..."
    if ! subscription-manager release --list; then
        log_error "Failed to check upgrade versions"
        exit 1
    fi

    # Step 4: Repository Management
    disable_repos=(
        "rhel-9-for-x86_64-baseos-rpms"
        "rhel-9-for-x86_64-appstream-rpms"
    )
    enable_repos=(
        "rhel-9-for-x86_64-baseos-eus-rpms"
        "rhel-9-for-x86_64-appstream-eus-rpms"
    )

    # Disable repositories
    progress "Step 3/6 - Disabling standard repositories..."
    for repo in "${disable_repos[@]}"; do
        if ! subscription-manager repos --disable="$repo"; then
            log_error "Failed to disable $repo"
            exit 1
        fi
    done

    # Enable EUS repositories
    progress "Step 4/6 - Enabling EUS repositories..."
    for repo in "${enable_repos[@]}"; do
        if ! subscription-manager repos --enable="$repo"; then
            log_error "Failed to enable $repo"
            exit 1
        fi
    done

    # Step 5: System Upgrade
#    progress "Step 5/6 - Performing system upgrade..."
#    if ! dnf upgrade -y; then
#        log_error "System upgrade failed"
#        exit 1
#    fi

    # Final Verification
    progress "Step 6/6 - Verifying repository status..."
    if ! subscription-manager repos --list-enabled | grep -E 'Repo ID|^Enabled'; then
        log_error "Verification failed"
        exit 1
    fi
}

# Start script execution
progress "Note: Detailed errors will be logged to: $LOG_FILE"
manage_subscription
