#!/bin/bash

# Define variables
SOURCE_PATH="/reartmp/tmp"
DEST_PATH="/win-share"
#ISO_FILE="<namefile.iso>"
#ISO_FILE=`hostname`_$( date +"%d%m%Y" ).iso
ISO_FILE="wrpj94_03122024_1436_Tue.iso"
#ZIP_FILE="<namefile.zip>"
ZIP_FILE="wrpj94_03122024_1436_Tue.zip"

# Check if the source ISO file exists
if [ -f "$SOURCE_PATH/$ISO_FILE" ]; then
    echo "Found ISO file: $SOURCE_PATH/$ISO_FILE"
    
    # Compress the ISO file into a ZIP archive
    echo "Compressing $ISO_FILE to $ZIP_FILE..."
    zip "$SOURCE_PATH/$ZIP_FILE" "$SOURCE_PATH/$ISO_FILE"
    
    # Check if the ZIP command was successful
    if [ $? -eq 0 ]; then
        echo "Compression successful."

        # Move the ZIP file to the destination directory
        echo "Moving $ZIP_FILE to $DEST_PATH..."
        mv "$SOURCE_PATH/$ZIP_FILE" "$DEST_PATH"
        
        # Verify if the move was successful
        if [ $? -eq 0 ]; then
            echo "File moved to $DEST_PATH successfully."
        else
            echo "Failed to move the file to $DEST_PATH."
            exit 1
        fi
    else
        echo "Compression failed. Please check the file and try again."
        exit 1
    fi
else
    echo "Source ISO file does not exist: $SOURCE_PATH/$ISO_FILE"
    exit 1
fi

# End of script

