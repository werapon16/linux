##!/bin/bash
#
## Variables
#USERNAME="db2fis1"
#PASSWORD="db2fis1@freewill"
#UID="1007"
#GROUP="db2iadm1"
#
## Create group if not exists
#if ! grep -q "^$GROUP:" /etc/group; then
#    groupadd $GROUP
#fi
#
## Create the user with specified UID, group, and shell
#useradd -u $UID -g $GROUP -s /bin/bash $USERNAME
#
## Set the user's password
#echo "$USERNAME:$PASSWORD" | chpasswd
#
## Ensure the password does not expire
#chage -M -1 $USERNAME
#
## Confirm user creation
#echo "User $USERNAME created with UID $UID, group $GROUP, and non-expiring password."


useradd -g db2iadm1 -u 1007 db2fis1

        cp /etc/skel/.bash* /home/db2fis1/

        echo -e "db2fis1 [${green}${RUN_FILE}${endColor}] : Setting home directory permission for db2fis1"
        #--------------------------------------------------------------------------------
        chown -R db2fis1:db2iadm1 /home/db2fis1
        chmod 755 /home/db2fis1

        echo -e "db2fis1 [${green}${RUN_FILE}${endColor}] : Setting Default password for db2fis1 user"
        #--------------------------------------------------------------------------------
        echo "db2fis1@freewill" | passwd --stdin db2fis1

chage -M 99999 db2fis1
